// CircleCropBatch.jsx
// Photoshop batch script:
//  - Prompts for a source folder and a destination folder
//  - Crops every image to a circle spanning top-to-bottom, edge-to-edge
//  - Requires square images (same X and Y pixel dimensions); non-square files are skipped
//  - Saves as transparent PNG at the original resolution (no resampling)
//
// Run via  File > Scripts > Browse...  in Photoshop.

#target photoshop

(function () {

    // ---- folder selection -------------------------------------------------
    var srcFolder = Folder.selectDialog("Select the SOURCE folder (images to crop)");
    if (srcFolder === null) return;

    var dstFolder = Folder.selectDialog("Select the DESTINATION folder (PNG output)");
    if (dstFolder === null) return;

    if (srcFolder.fsName === dstFolder.fsName) {
        alert("Source and destination folders must be different.");
        return;
    }

    // ---- gather image files ----------------------------------------------
    var files = srcFolder.getFiles(function (f) {
        return (f instanceof File) &&
               /\.(jpg|jpeg|png|tif|tiff|psd|bmp)$/i.test(f.name);
    });

    if (files.length === 0) {
        alert("No supported images (jpg, jpeg, png, tif, tiff, psd, bmp) found in:\n" + srcFolder.fsName);
        return;
    }

    // ---- save & set app state --------------------------------------------
    var savedRulerUnits = app.preferences.rulerUnits;
    var savedDialogs    = app.displayDialogs;
    app.preferences.rulerUnits = Units.PIXELS;
    app.displayDialogs = DialogModes.NO;

    var done = 0;
    var skipped = [];
    var failed  = [];

    // Elliptical selection via Action Manager (DOM API cannot make ellipses)
    function selectEllipse(top, left, bottom, right) {
        var desc = new ActionDescriptor();
        var ref  = new ActionReference();
        ref.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));
        desc.putReference(charIDToTypeID("null"), ref);
        var elps = new ActionDescriptor();
        elps.putUnitDouble(charIDToTypeID("Top "), charIDToTypeID("#Pxl"), top);
        elps.putUnitDouble(charIDToTypeID("Left"), charIDToTypeID("#Pxl"), left);
        elps.putUnitDouble(charIDToTypeID("Btom"), charIDToTypeID("#Pxl"), bottom);
        elps.putUnitDouble(charIDToTypeID("Rght"), charIDToTypeID("#Pxl"), right);
        desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Elps"), elps);
        desc.putBoolean(charIDToTypeID("AntA"), true); // anti-aliased edge
        executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
    }

    function baseName(fileName) {
        return fileName.replace(/\.[^\.]+$/, "");
    }

    // ---- process each file ------------------------------------------------
    for (var i = 0; i < files.length; i++) {
        var doc = null;
        try {
            doc = app.open(files[i]);

            var w = doc.width.as("px");
            var h = doc.height.as("px");

            // Must be square: circle is edge-to-edge in BOTH directions
            if (Math.round(w) !== Math.round(h)) {
                skipped.push(files[i].name + "  (" + Math.round(w) + "x" + Math.round(h) + " - not square)");
                doc.close(SaveOptions.DONOTSAVECHANGES);
                doc = null;
                continue;
            }

            // Normalize mode so PNG + transparency always works
            if (doc.mode !== DocumentMode.RGB) doc.changeMode(ChangeMode.RGB);
            if (doc.bitsPerChannel !== BitsPerChannelType.EIGHT) {
                doc.bitsPerChannel = BitsPerChannelType.EIGHT;
            }

            // Flatten, then promote background so transparency is possible
            doc.flatten();
            doc.activeLayer.isBackgroundLayer = false;

            // Circle: full canvas, top-to-bottom, edge-to-edge
            selectEllipse(0, 0, h, w);

            // Delete everything OUTSIDE the circle
            doc.selection.invert();
            doc.selection.clear();
            doc.selection.deselect();

            // Save transparent PNG — same pixel dimensions, no resampling
            var outFile = new File(dstFolder.fsName + "/" + baseName(files[i].name) + ".png");
            var pngOpts = new PNGSaveOptions();
            pngOpts.compression = 6;
            pngOpts.interlaced = false;
            doc.saveAs(outFile, pngOpts, true, Extension.LOWERCASE);

            doc.close(SaveOptions.DONOTSAVECHANGES);
            doc = null;
            done++;
        } catch (e) {
            failed.push(files[i].name + "  (" + e.message + ")");
            try { if (doc !== null) doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
        }
    }

    // ---- restore app state & report ---------------------------------------
    app.preferences.rulerUnits = savedRulerUnits;
    app.displayDialogs = savedDialogs;

    var msg = "Done. " + done + " of " + files.length + " image(s) cropped.";
    if (skipped.length > 0) msg += "\n\nSkipped (not square):\n" + skipped.join("\n");
    if (failed.length  > 0) msg += "\n\nFailed:\n" + failed.join("\n");
    alert(msg);

})();
